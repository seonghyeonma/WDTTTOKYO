# 🗼🌸 Tokyo 2025 Travel Guide

모바일 최적화 도쿄 여행 가이드북 (2025.3.20 — 3.22)

## Features
- 📱 모바일 퍼스트 디자인 (430px 최적화)
- 📍 일별 타임라인 일정표
- 🍽️ 식당 예약 내역 내장
- ✅ 인터랙티브 준비물 체크리스트
- 🆘 긴급 연락처 (원터치 전화 연결)
- 🌸 스크롤 애니메이션 & sticky 네비게이션

## Deploy on Vercel

1. 이 폴더를 GitHub repo에 push
2. [Vercel](https://vercel.com)에서 해당 repo import
3. Framework Preset: `Other`
4. Output Directory: `public`
5. Deploy!

## Project Structure
```
├── public/
│   └── index.html    ← 가이드북 메인 파일
├── vercel.json       ← Vercel 배포 설정
├── package.json
└── README.md
```

## Tech Stack
- Pure HTML / CSS / Vanilla JS
- Google Fonts (Noto Sans KR, DM Mono)
- Zero dependencies, no build step
